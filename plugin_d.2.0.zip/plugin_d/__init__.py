import os, configparser

from qgis.core import QgsMessageLog

from qgis.PyQt.QtWidgets import QLabel

class Plugin:
    def __init__(self, iface):
        self.iface = iface

    def initGui(self):

        metadata = configparser.ConfigParser()
        metadata.read(os.path.join(os.path.dirname(__file__), "metadata.txt"))

        name = '{} [{}]'.format(
            metadata["general"]["name"],
            metadata["general"]["version"]
        )

        QgsMessageLog.logMessage('Plugin {} loaded'.format(name))

        self.widget = QLabel(name)
        self.action = self.iface.pluginToolBar().addWidget(self.widget)

    def unload(self):
        self.iface.pluginToolBar().removeAction(self.action)

def classFactory(iface):
    return Plugin(iface)
